﻿using System.ComponentModel.DataAnnotations;

namespace _2d_array
{
    internal class Program
    {
        static int sum = 0, max = 0;
        static int sum_array(int[,] s)
        {
            for(int i=0;i<4;i++)
            {
                for(int j=0;j<4;j++)
                {
                    sum = s[i, j] + s[i, j + 1] + s[i, j + 2] + s[i + 1, j + 1] +
                        s[i + 2, j] + s[i+2,j + 1] + s[i + 2, j + 2];
                }
                if(max<sum)
                {
                    max = sum;
                }
            }
            return max;
        }
        static void Main(string[] args)
        {
            int[,] arr = new int[6, 6] { { 1, 1, 1, 0, 0, 0 }, { 0, 1, 0, 0, 0, 0 },
            {1,1,1,0,0,0 }, {0,0,2,4,4,0 },{ 0,0,0,2,0,0 },{0,0,1,2,4,0 } };
            
            int result = sum_array(arr);
            Console.WriteLine(result);
        }
    }
}